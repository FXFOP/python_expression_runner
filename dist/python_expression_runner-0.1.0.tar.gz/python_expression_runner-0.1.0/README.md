# Python Expression Runner

Python Expression Runner is a symbolic computation library for evaluating Python expressions dynamically.

## Features
- Add variables to context
- Evaluate Python expressions dynamically
- Support for custom functions

## Installation

```bash
pip install python_expression_runner
